<footer class="footer">
    <div class="container">
        <nav class="float-left">
            <ul>
                <li>
                    <a href="">
                        {{ __('HominTec') }}
                    </a>
                </li>
                <li>
                    <a href="">
                        {{ __('A propos') }}
                    </a>
                </li>
                <li>
                    <a href="">
                        {{ __('Licenses') }}
                    </a>
                </li>
            </ul>
        </nav>
        <div class="copyright float-right">
            &copy;
            <script>
                document.write(new Date().getFullYear())
            </script>. All rights reserved. <a href="#">HominTec</a>.
        </div>
    </div>
</footer>