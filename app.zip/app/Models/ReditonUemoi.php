<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ReditonUemoi extends Model
{

    protected $table="rediton_uemo";
}
