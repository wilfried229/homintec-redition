@extends('template')



 @section('content')
  
 @endsection

