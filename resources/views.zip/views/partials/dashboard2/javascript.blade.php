

<script src="{{asset('Admin2/vendor/jquery/jquery.min.js')}}"></script>
  <script src="{{asset('Admin2/vendor/bootstrap/js/bootstrap.bundle.min.js')}}"></script>

  <!-- Core plugin JavaScript-->
  <script src="{{asset('Admin2/vendor/jquery-easing/jquery.easing.min.js')}}"></script>

  <!-- Custom scripts for all pages-->
  <script src="{{asset('Admin2/js/sb-admin-2.min.js')}}"></script>

  <!-- Page level plugins -->

  <script src="{{asset('Admin2/vendor/datatables/jquery.dataTables.min.js')}}"></script>
  <script src="{{asset('Admin2/vendor/datatables/dataTables.bootstrap4.min.js')}}"></script>

  <!-- Page level custom scripts -->
  <script src="{{asset('Admin2/js/demo/datatables-demo.js')}}"></script>
